/**
 * PCA and K-means Clustering Visualization
 * This file contains all JavaScript code needed for the visualization.
 */

// This will hold our analysis results
let analysisResults = {
    eigenvalues: [],
    explainedVariance: [],
    cumulativeVariance: [],
    pcScores: [],
    eigenvectors: [],
    topAttributes: [],
    attributeRanking: [],
    kValues: [],
    inertiaValues: [],
    optimalK: 2,
    clusters: []
}

// Function to update scatterplot matrix
function updateScatterplotMatrix(dimension) {
    // Clear existing matrix
    d3.select('#scatterplot-matrix svg').remove();
    
    // Recreate with new attributes
    createScatterplotMatrix();
}

// Function to create elbow plot
function createElbowPlot() {
    const width = 500;
    const height = 300;
    const margin = { top: 30, right: 30, bottom: 50, left: 50 };
    
    // Create SVG
    const svg = d3.select('#elbow-plot')
        .append('svg')
        .attr('width', width)
        .attr('height', height);
        
    const g = svg.append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`);
        
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Create scales
    const xScale = d3.scaleLinear()
        .domain([1, d3.max(analysisResults.kValues)])
        .range([0, innerWidth])
        .nice();
        
    const yScale = d3.scaleLinear()
        .domain([0, d3.max(analysisResults.inertiaValues) * 1.1])
        .range([innerHeight, 0])
        .nice();
        
    // Create axes
    const xAxis = d3.axisBottom(xScale).ticks(analysisResults.kValues.length).tickFormat(d3.format('d'));
    const yAxis = d3.axisLeft(yScale);
    
    g.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0,${innerHeight})`)
        .call(xAxis);
        
    g.append('g')
        .attr('class', 'y-axis')
        .call(yAxis);
        
    // Add axis labels
    g.append('text')
        .attr('text-anchor', 'middle')
        .attr('x', innerWidth / 2)
        .attr('y', innerHeight + 40)
        .text('Number of Clusters (k)');
        
    g.append('text')
        .attr('text-anchor', 'middle')
        .attr('transform', `translate(${-35},${innerHeight / 2}) rotate(-90)`)
        .text('Inertia (Within-Cluster Sum of Squares)');
        
    // Create line
    const line = d3.line()
        .x((d, i) => xScale(analysisResults.kValues[i]))
        .y(d => yScale(d));
        
    g.append('path')
        .datum(analysisResults.inertiaValues)
        .attr('fill', 'none')
        .attr('stroke', '#4682b4')
        .attr('stroke-width', 2)
        .attr('d', line);
        
    // Add points
    g.selectAll('.point')
        .data(analysisResults.inertiaValues)
        .enter()
        .append('circle')
        .attr('class', 'point')
        .attr('cx', (d, i) => xScale(analysisResults.kValues[i]))
        .attr('cy', d => yScale(d))
        .attr('r', 4)
        .attr('fill', (d, i) => analysisResults.kValues[i] === analysisResults.optimalK ? 'red' : '#4682b4');
        
    // Highlight optimal k
    g.append('circle')
        .attr('cx', xScale(analysisResults.optimalK))
        .attr('cy', yScale(analysisResults.inertiaValues[analysisResults.optimalK - 1]))
        .attr('r', 6)
        .attr('fill', 'none')
        .attr('stroke', 'red')
        .attr('stroke-width', 2);
        
    g.append('text')
        .attr('x', xScale(analysisResults.optimalK) + 10)
        .attr('y', yScale(analysisResults.inertiaValues[analysisResults.optimalK - 1]) - 10)
        .attr('fill', 'red')
        .text(`Optimal k = ${analysisResults.optimalK}`);
}

// Function to create cluster plot
function createClusterPlot() {
    const width = 500;
    const height = 400;
    const margin = { top: 30, right: 30, bottom: 50, left: 50 };
    
    // Create SVG
    const svg = d3.select('#cluster-plot')
        .append('svg')
        .attr('width', width)
        .attr('height', height);
        
    const g = svg.append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`);
        
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Get first two principal components
    const pc1 = analysisResults.pcScores.map(d => d[0]);
    const pc2 = analysisResults.pcScores.map(d => d[1]);
    
    // Create scales
    const xScale = d3.scaleLinear()
        .domain([d3.min(pc1) * 1.1, d3.max(pc1) * 1.1])
        .range([0, innerWidth])
        .nice();
        
    const yScale = d3.scaleLinear()
        .domain([d3.min(pc2) * 1.1, d3.max(pc2) * 1.1])
        .range([innerHeight, 0])
        .nice();
        
    // Set up color scale for clusters
    const colorScale = d3.scaleOrdinal(d3.schemeCategory10);
    
    // Create axes
    const xAxis = d3.axisBottom(xScale);
    const yAxis = d3.axisLeft(yScale);
    
    g.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0,${innerHeight})`)
        .call(xAxis);
        
    g.append('g')
        .attr('class', 'y-axis')
        .call(yAxis);
        
    // Add axis labels
    g.append('text')
        .attr('text-anchor', 'middle')
        .attr('x', innerWidth / 2)
        .attr('y', innerHeight + 40)
        .text('Principal Component 1');
        
    g.append('text')
        .attr('text-anchor', 'middle')
        .attr('transform', `translate(${-35},${innerHeight / 2}) rotate(-90)`)
        .text('Principal Component 2');
        
    // Create scatter plot with clusters
    g.selectAll('.dot')
        .data(analysisResults.pcScores.map((d, i) => ({
            pc1: d[0],
            pc2: d[1],
            cluster: analysisResults.clusters[i]
        })))
        .enter()
        .append('circle')
        .attr('class', 'dot')
        .attr('cx', d => xScale(d.pc1))
        .attr('cy', d => yScale(d.pc2))
        .attr('r', 5)
        .attr('fill', d => colorScale(d.cluster))
        .attr('opacity', 0.7)
        .on('mouseover', function(event, d) {
            d3.select(this)
                .attr('r', 8)
                .attr('stroke', '#333')
                .attr('stroke-width', 2);
                
            // Create tooltip
            const tooltip = d3.select('body').append('div')
                .attr('class', 'tooltip')
                .style('opacity', 0);
                
            tooltip.transition()
                .duration(200)
                .style('opacity', 0.9);
                
            tooltip.html(`
                <strong>Cluster:</strong> ${d.cluster + 1}<br>
                <strong>PC1:</strong> ${d.pc1.toFixed(3)}<br>
                <strong>PC2:</strong> ${d.pc2.toFixed(3)}
            `)
            .style('left', (event.pageX + 10) + 'px')
            .style('top', (event.pageY - 28) + 'px');
        })
        .on('mouseout', function() {
            d3.select(this)
                .attr('r', 5)
                .attr('stroke', 'none');
                
            d3.select('.tooltip').remove();
        });
        
    // Origin lines
    g.append('line')
        .attr('x1', xScale(0))
        .attr('x2', xScale(0))
        .attr('y1', 0)
        .attr('y2', innerHeight)
        .attr('stroke', '#ccc')
        .attr('stroke-width', 1);
        
    g.append('line')
        .attr('x1', 0)
        .attr('x2', innerWidth)
        .attr('y1', yScale(0))
        .attr('y2', yScale(0))
        .attr('stroke', '#ccc')
        .attr('stroke-width', 1);
        
    // Add legend
    const legend = svg.append('g')
        .attr('class', 'legend')
        .attr('transform', `translate(${width - margin.right - 100}, ${margin.top})`);
        
    const clusters = [...new Set(analysisResults.clusters)].sort();
    
    clusters.forEach((cluster, i) => {
        legend.append('rect')
            .attr('x', 0)
            .attr('y', i * 20)
            .attr('width', 12)
            .attr('height', 12)
            .attr('fill', colorScale(cluster));
            
        legend.append('text')
            .attr('x', 20)
            .attr('y', i * 20 + 10)
            .text(`Cluster ${cluster + 1}`);
    });
}

// Run the analysis once the page loads
window.addEventListener('load', function() {
    runAnalysis();
});;

// Function to run the entire analysis process
async function runAnalysis() {
    try {
        // Generate synthetic data based on the structure of the original dataset
        const sampleData = generateSampleData();
        
        // Process the data
        processData(sampleData);
    } catch (error) {
        console.error("Error analyzing data:", error);
        document.body.innerHTML = `<div class="container"><h1>Error</h1><p>Failed to analyze data: ${error.message}</p></div>`;
    }
}

// Function to generate sample data matching the structure of the original CSV
function generateSampleData() {
    const sampleData = [];
    
    // Create 29 sample data points (matching the original dataset size)
    for (let i = 0; i < 29; i++) {
        const row = {
            HHID: i + 1,
            PN: 10 + i
        };
        
        // Add numeric columns with random but related values
        // These are simplified placeholders that maintain some correlation
        const baseVal = Math.random() * 10 + 5;
        
        // Memory tests (IMRC series)
        for (let j = 1; j <= 13; j++) {
            row[`R${j}IMRC${j <= 2 ? '20' : ''}`] = Math.round(baseVal + Math.random() * 5);
        }
        
        // Delayed recall tests (DLRC series)
        for (let j = 1; j <= 13; j++) {
            row[`R${j}DLRC${j <= 2 ? '20' : ''}`] = Math.round(baseVal * 0.6 + Math.random() * 4);
        }
        
        // TR series
        for (let j = 1; j <= 13; j++) {
            const suffix = j <= 2 ? '40' : '20';
            row[`R${j}TR${suffix}`] = Math.round(baseVal * 1.7 + Math.random() * 7);
        }
        
        // Self-memory tests (SLFMEM series)
        for (let j = 1; j <= 15; j++) {
            row[`R${j}SLFMEM`] = Math.round(baseVal * 0.4 + Math.random() * 3);
        }
        
        // Past memory tests (PSTMEM series)
        for (let j = 1; j <= 15; j++) {
            row[`R${j}PSTMEM`] = Math.round(baseVal * 0.35 + Math.random() * 3);
        }
        
        // Social security related (SSWRER series)
        for (let j = 1; j <= 15; j++) {
            row[`R${j}SSWRER`] = Math.round(20000 + baseVal * 1000 + Math.random() * 10000);
            row[`H${j}SSWRER`] = row[`R${j}SSWRER`] + Math.round(Math.random() * 5000);
        }
        
        // Randomly set some values to null to simulate missing data
        Object.keys(row).forEach(key => {
            if (key !== 'HHID' && key !== 'PN' && Math.random() < 0.3) {
                row[key] = null;
            }
        });
        
        sampleData.push(row);
    }
    
    return sampleData;
}

// Function to process the CSV data
function processData(data) {
    // Replace "NA" with null
    data.forEach(row => {
        Object.keys(row).forEach(key => {
            if (row[key] === "NA") {
                row[key] = null;
            }
        });
    });
    
    // Select columns with at least 15 non-null values (excluding ID columns)
    const numericColumns = [];
    
    // Find numeric columns
    Object.keys(data[0]).forEach(field => {
        if (field !== 'HHID' && field !== 'PN') {
            const nonNullCount = data.filter(row => 
                row[field] !== null && !isNaN(row[field])
            ).length;
            
            if (nonNullCount >= 15) {
                numericColumns.push(field);
            }
        }
    });
    
    // Calculate means for each column for imputation
    const columnMeans = {};
    numericColumns.forEach(col => {
        const values = data
            .map(row => row[col])
            .filter(val => val !== null && !isNaN(val));
        
        if (values.length > 0) {
            columnMeans[col] = values.reduce((sum, val) => sum + val, 0) / values.length;
        } else {
            columnMeans[col] = 0;
        }
    });
    
    // Create imputed dataset
    const imputedData = data.map(row => {
        const newRow = {};
        numericColumns.forEach(col => {
            if (row[col] !== null && !isNaN(row[col])) {
                newRow[col] = row[col];
            } else {
                newRow[col] = columnMeans[col];
            }
        });
        return newRow;
    });
    
    // Extract numeric matrix from imputed data
    const dataMatrix = imputedData.map(row => 
        numericColumns.map(col => row[col])
    );
    
    // Standardize the data
    const { means, stds, standardizedData } = standardizeData(dataMatrix);
    
    // Perform PCA
    const pcaResults = performPCA(standardizedData);
    
    // Find top attributes with highest loadings
    const topAttributesResults = findTopAttributes(pcaResults.eigenvectors, numericColumns);
    
    // Perform k-means clustering
    const clusteringResults = performKMeansClustering(pcaResults.projectedData);
    
    // Combine all results
    analysisResults = {
        eigenvalues: pcaResults.eigenvalues,
        explainedVariance: pcaResults.explainedVariance,
        cumulativeVariance: pcaResults.cumulativeVariance,
        pcScores: pcaResults.projectedData,
        eigenvectors: pcaResults.eigenvectors,
        topAttributes: topAttributesResults.topAttributes,
        attributeRanking: topAttributesResults.attributeRanking,
        kValues: clusteringResults.kValues,
        inertiaValues: clusteringResults.inertiaValues,
        optimalK: clusteringResults.optimalK,
        clusters: clusteringResults.clusters,
        numericColumns: numericColumns,
        dataMatrix: dataMatrix
    };
    
    // Create all visualizations
    createVisualizations();
}

// Function to standardize data
function standardizeData(dataMatrix) {
    const numColumns = dataMatrix[0].length;
    const numRows = dataMatrix.length;
    
    // Calculate means
    const means = Array(numColumns).fill(0);
    for (let i = 0; i < numColumns; i++) {
        for (let j = 0; j < numRows; j++) {
            means[i] += dataMatrix[j][i];
        }
        means[i] /= numRows;
    }
    
    // Calculate standard deviations
    const stds = Array(numColumns).fill(0);
    for (let i = 0; i < numColumns; i++) {
        for (let j = 0; j < numRows; j++) {
            stds[i] += Math.pow(dataMatrix[j][i] - means[i], 2);
        }
        stds[i] = Math.sqrt(stds[i] / numRows);
        // Handle zero standard deviation
        if (stds[i] === 0) stds[i] = 1;
    }
    
    // Standardize
    const standardizedData = dataMatrix.map(row => 
        row.map((val, colIndex) => (val - means[colIndex]) / stds[colIndex])
    );
    
    return { means, stds, standardizedData };
}

// Function to perform PCA
function performPCA(standardizedData) {
    // Calculate covariance matrix
    const covMatrix = math.multiply(
        math.transpose(standardizedData),
        standardizedData
    );
    
    // Divide by n-1
    for (let i = 0; i < covMatrix.length; i++) {
        for (let j = 0; j < covMatrix[i].length; j++) {
            covMatrix[i][j] /= (standardizedData.length - 1);
        }
    }
    
    // Calculate eigenvalues and eigenvectors
    const eig = numeric.eig(covMatrix);
    
    // Extract real parts of eigenvalues
    const eigenvalues = eig.lambda.x;
    
    // Create pairs of eigenvalue and index
    const pairs = eigenvalues.map((val, idx) => ({ value: val, index: idx }));
    
    // Sort by eigenvalue in descending order
    pairs.sort((a, b) => b.value - a.value);
    
    // Reorder eigenvalues
    const sortedEigenvalues = pairs.map(pair => eigenvalues[pair.index]);
    
    // Reorder eigenvectors
    const sortedEigenvectors = pairs.map(pair => {
        const col = [];
        for (let i = 0; i < eig.E.x.length; i++) {
            col.push(eig.E.x[i][pair.index]);
        }
        return col;
    });
    
    // Calculate explained variance
    const totalVariance = sortedEigenvalues.reduce((sum, val) => sum + val, 0);
    const explainedVariance = sortedEigenvalues.map(val => val / totalVariance);
    
    // Calculate cumulative variance
    const cumulativeVariance = [];
    let cumSum = 0;
    for (const variance of explainedVariance) {
        cumSum += variance;
        cumulativeVariance.push(cumSum);
    }
    
    // Project data onto principal components
    const projectedData = standardizedData.map(row => {
        return sortedEigenvectors.map(eigenvector => {
            let sum = 0;
            for (let i = 0; i < row.length; i++) {
                sum += row[i] * eigenvector[i];
            }
            return sum;
        });
    });
    
    return {
        eigenvalues: sortedEigenvalues,
        eigenvectors: sortedEigenvectors,
        explainedVariance,
        cumulativeVariance,
        projectedData
    };
}

// Function to find top attributes based on PCA loadings
function findTopAttributes(eigenvectors, numericColumns) {
    // Use first 2 PCs by default
    const numPCs = 2;
    const pcLoadings = eigenvectors.slice(0, numPCs);
    
    // Calculate attribute scores based on squared loadings
    const attributeScores = Array(numericColumns.length).fill(0);
    
    for (let i = 0; i < numPCs; i++) {
        for (let j = 0; j < numericColumns.length; j++) {
            attributeScores[j] += Math.pow(pcLoadings[i][j], 2);
        }
    }
    
    // Sort attributes by score
    const attributeRanking = attributeScores.map((score, index) => ({ 
        score, 
        name: numericColumns[index] 
    }));
    attributeRanking.sort((a, b) => b.score - a.score);
    
    // Update table
    const tbody = d3.select('#attributes-table tbody');
    
    const rows = tbody.selectAll('tr')
        .data(attributeRanking.slice(0, 10));
        
    rows.attr('class', (d, i) => i < 4 ? 'highlight' : '');
    
    rows.select('td:nth-child(3)')
        .text(d => d.score.toFixed(4));
        
    // Update top attributes for scatterplot matrix
    analysisResults.topAttributes = attributeRanking.slice(0, 4).map(d => d.name);
    updateScatterplotMatrix(dimension);
}

// Function to create scatterplot matrix
function createScatterplotMatrix() {
    // Get top attributes data
    const topAttrs = analysisResults.topAttributes;
    const attrData = analysisResults.dataMatrix.map((row, i) => {
        const obj = {
            index: i,
            cluster: analysisResults.clusters[i] || 0
        };
        
        topAttrs.forEach((attr, j) => {
            const attrIndex = analysisResults.numericColumns.indexOf(attr);
            obj[attr] = row[attrIndex];
        });
        
        return obj;
    });
    
    const size = 150;
    const padding = 20;
    const n = topAttrs.length;
    
    // Set up SVG
    const width = size * n + padding * (n + 1);
    const height = width;
    
    const svg = d3.select('#scatterplot-matrix')
        .append('svg')
        .attr('width', width)
        .attr('height', height)
        .attr('class', 'scatterplot-matrix');
        
    // Scales for each attribute
    const scales = {};
    
    topAttrs.forEach(attr => {
        const values = attrData.map(d => d[attr]);
        scales[attr] = d3.scaleLinear()
            .domain([d3.min(values), d3.max(values)])
            .range([padding, size - padding])
            .nice();
    });
    
    // Set up color scale for clusters
    const colorScale = d3.scaleOrdinal(d3.schemeCategory10);
    
    // Create cells
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
            const cell = svg.append('g')
                .attr('transform', `translate(${j * size + padding},${i * size + padding})`);
                
            const attr1 = topAttrs[j];
            const attr2 = topAttrs[i];
            
            // Add background
            cell.append('rect')
                .attr('width', size)
                .attr('height', size)
                .attr('fill', '#f9f9f9')
                .attr('stroke', '#ddd');
            
            if (i === j) {
                // Diagonal: show attribute name
                cell.append('text')
                    .attr('x', size / 2)
                    .attr('y', size / 2)
                    .attr('text-anchor', 'middle')
                    .attr('dominant-baseline', 'middle')
                    .attr('font-weight', 'bold')
                    .text(attr1);
            } else {
                // Off-diagonal: scatterplots
                cell.selectAll('.dot')
                    .data(attrData)
                    .enter()
                    .append('circle')
                    .attr('class', 'dot')
                    .attr('cx', d => scales[attr1](d[attr1]))
                    .attr('cy', d => scales[attr2](d[attr2]))
                    .attr('r', 3)
                    .attr('fill', d => colorScale(d.cluster))
                    .attr('opacity', 0.7);
                    
                // Add axes
                if (i === n - 1) {
                    // Bottom row: add x-axis
                    const xAxis = d3.axisBottom(scales[attr1])
                        .ticks(5)
                        .tickSize(-size);
                        
                    cell.append('g')
                        .attr('class', 'axis')
                        .attr('transform', `translate(0,${size})`)
                        .call(xAxis);
                }
                
                if (j === 0) {
                    // Leftmost column: add y-axis
                    const yAxis = d3.axisLeft(scales[attr2])
                        .ticks(5)
                        .tickSize(-size);
                        
                    cell.append('g')
                        .attr('class', 'axis')
                        .call(yAxis);
                }
            }
        }
    }
}
    
    // Get top 4 attributes
    const topAttributes = attributeRanking.slice(0, 4).map(item => item.name);
    
    return { topAttributes, attributeRanking };
}

// Function to perform k-means clustering
function performKMeansClustering(pcScores) {
    // Helper function: Euclidean distance
    function euclideanDistance(a, b) {
        let sum = 0;
        for (let i = 0; i < a.length; i++) {
            sum += Math.pow(a[i] - b[i], 2);
        }
        return Math.sqrt(sum);
    }
    
    // Helper function: Check if arrays are equal
    function arraysEqual(a, b) {
        if (a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) {
            if (a[i] !== b[i]) return false;
        }
        return true;
    }
    
    // K-means clustering function
    function kMeans(data, k, maxIterations = 100) {
        const n = data.length;
        const d = data[0].length;
        let centroids = [];
        
        // Initialize centroids randomly
        const indices = new Set();
        while (indices.size < k) {
            indices.add(Math.floor(Math.random() * n));
        }
        
        centroids = Array.from(indices).map(i => data[i].slice());
        
        // Cluster assignments
        let assignments = Array(n).fill(-1);
        let prevAssignments = Array(n).fill(-2);
        let iterations = 0;
        
        // Iterate until convergence or max iterations
        while (!arraysEqual(assignments, prevAssignments) && iterations < maxIterations) {
            prevAssignments = assignments.slice();
            
            // Assign points to nearest centroid
            for (let i = 0; i < n; i++) {
                let minDist = Infinity;
                let minCluster = -1;
                
                for (let j = 0; j < k; j++) {
                    const dist = euclideanDistance(data[i], centroids[j]);
                    if (dist < minDist) {
                        minDist = dist;
                        minCluster = j;
                    }
                }
                
                assignments[i] = minCluster;
            }
            
            // Update centroids
            const newCentroids = Array(k).fill().map(() => Array(d).fill(0));
            const counts = Array(k).fill(0);
            
            for (let i = 0; i < n; i++) {
                const cluster = assignments[i];
                counts[cluster]++;
                
                for (let j = 0; j < d; j++) {
                    newCentroids[cluster][j] += data[i][j];
                }
            }
            
            for (let i = 0; i < k; i++) {
                if (counts[i] > 0) {
                    for (let j = 0; j < d; j++) {
                        newCentroids[i][j] /= counts[i];
                    }
                } else {
                    // If a cluster is empty, reinitialize it
                    const randomIndex = Math.floor(Math.random() * n);
                    newCentroids[i] = data[randomIndex].slice();
                }
            }
            
            centroids = newCentroids;
            iterations++;
        }
        
        // Calculate inertia (sum of squared distances to centroids)
        let inertia = 0;
        for (let i = 0; i < n; i++) {
            inertia += Math.pow(euclideanDistance(data[i], centroids[assignments[i]]), 2);
        }
        
        return { assignments, centroids, inertia, iterations };
    }
    
    // Run k-means with different k values
    const maxK = Math.min(10, Math.floor(pcScores.length / 3));
    const kValues = Array.from({ length: maxK }, (_, i) => i + 1);
    const inertiaValues = [];
    
    for (const k of kValues) {
        // Use first 2 PCs for clustering
        const result = kMeans(pcScores.map(row => row.slice(0, 2)), k);
        inertiaValues.push(result.inertia);
    }
    
    // Find elbow point
    function findElbowPoint(kValues, inertiaValues) {
        if (kValues.length <= 2) return 2;
        
        let maxCurvature = -Infinity;
        let elbowK = 2;
        
        for (let i = 1; i < kValues.length - 1; i++) {
            const x1 = kValues[i-1];
            const y1 = inertiaValues[i-1];
            const x2 = kValues[i];
            const y2 = inertiaValues[i];
            const x3 = kValues[i+1];
            const y3 = inertiaValues[i+1];
            
            // Calculate angles
            const a = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
            const b = Math.sqrt(Math.pow(x3 - x2, 2) + Math.pow(y3 - y2, 2));
            const c = Math.sqrt(Math.pow(x3 - x1, 2) + Math.pow(y3 - y1, 2));
            
            // Compute angle using law of cosines
            const angleC = Math.acos((a*a + b*b - c*c) / (2*a*b));
            
            if (angleC > maxCurvature) {
                maxCurvature = angleC;
                elbowK = kValues[i];
            }
        }
        
        return elbowK;
    }
    
    // Find optimal k
    const optimalK = findElbowPoint(kValues, inertiaValues);
    
    // Final clustering with optimal k
    const finalClustering = kMeans(pcScores.map(row => row.slice(0, 2)), optimalK);
    
    return {
        kValues,
        inertiaValues,
        optimalK,
        clusters: finalClustering.assignments
    };
}

// Function to create all visualizations
function createVisualizations() {
    // Create scree plot
    createScreePlot();
    
    // Create biplot
    createBiplot();
    
    // Create attributes table
    createAttributesTable();
    
    // Create scatterplot matrix
    createScatterplotMatrix();
    
    // Create elbow plot
    createElbowPlot();
    
    // Create cluster plot
    createClusterPlot();
    
    // Add dimension slider functionality
    document.getElementById('dimension-slider').addEventListener('input', function() {
        const value = parseInt(this.value);
        document.getElementById('dimension-value').textContent = value;
        
        // Update visualizations based on selected dimensionality
        updateScreePlot(value);
        updateAttributesTable(value);
        updateScatterplotMatrix(value);
    });
}

// Function to create scree plot
function createScreePlot() {
    const width = 500;
    const height = 300;
    const margin = { top: 30, right: 30, bottom: 60, left: 60 };
    
    // Create SVG
    const svg = d3.select('#scree-plot')
        .append('svg')
        .attr('width', width)
        .attr('height', height);
        
    const g = svg.append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`);
        
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Create scales
    const xScale = d3.scaleLinear()
        .domain([0, Math.min(analysisResults.eigenvalues.length, 20)])
        .range([0, innerWidth]);
        
    const yScale = d3.scaleLinear()
        .domain([0, d3.max(analysisResults.eigenvalues)])
        .range([innerHeight, 0])
        .nice();
        
    const y2Scale = d3.scaleLinear()
        .domain([0, 1])
        .range([innerHeight, 0]);
        
    // Create axes
    const xAxis = d3.axisBottom(xScale).ticks(Math.min(analysisResults.eigenvalues.length, 10)).tickFormat(d => Math.round(d));
    const yAxis = d3.axisLeft(yScale);
    const y2Axis = d3.axisRight(y2Scale).ticks(5).tickFormat(d3.format(".0%"));
    
    g.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0,${innerHeight})`)
        .call(xAxis);
        
    g.append('g')
        .attr('class', 'y-axis')
        .call(yAxis);
        
    g.append('g')
        .attr('class', 'y2-axis')
        .attr('transform', `translate(${innerWidth},0)`)
        .call(y2Axis);
        
    // Add axis labels
    g.append('text')
        .attr('class', 'x-axis-label')
        .attr('text-anchor', 'middle')
        .attr('x', innerWidth / 2)
        .attr('y', innerHeight + 40)
        .text('Principal Component');
        
    g.append('text')
        .attr('class', 'y-axis-label')
        .attr('text-anchor', 'middle')
        .attr('transform', `translate(${-40},${innerHeight / 2}) rotate(-90)`)
        .text('Eigenvalue');
        
    g.append('text')
        .attr('class', 'y2-axis-label')
        .attr('text-anchor', 'middle')
        .attr('transform', `translate(${innerWidth + 40},${innerHeight / 2}) rotate(90)`)
        .text('Cumulative Variance Explained');
        
    // Create bars for eigenvalues
    const bars = g.selectAll('.eigenvalue-bar')
        .data(analysisResults.eigenvalues.slice(0, 20))
        .enter()
        .append('rect')
        .attr('class', 'eigenvalue-bar')
        .attr('x', (d, i) => xScale(i) + 2)
        .attr('y', d => yScale(d))
        .attr('width', innerWidth / Math.min(analysisResults.eigenvalues.length, 20) - 4)
        .attr('height', d => innerHeight - yScale(d))
        .attr('fill', '#4682b4');
        
    // Add line for cumulative variance
    const line = d3.line()
        .x((d, i) => xScale(i))
        .y(d => y2Scale(d));
        
    g.append('path')
        .datum(analysisResults.cumulativeVariance.slice(0, 20))
        .attr('class', 'cumulative-line')
        .attr('fill', 'none')
        .attr('stroke', '#ff7f0e')
        .attr('stroke-width', 2)
        .attr('d', line);
        
    // Add a vertical line for selected dimensionality
    const dimensionLine = g.append('line')
        .attr('class', 'dimension-line')
        .attr('x1', xScale(1))
        .attr('x2', xScale(1))
        .attr('y1', 0)
        .attr('y2', innerHeight)
        .attr('stroke', 'red')
        .attr('stroke-width', 2)
        .attr('stroke-dasharray', '5,5');
        
    // Add cumulative variance value
    const varianceText = g.append('text')
        .attr('class', 'variance-text')
        .attr('x', xScale(1) + 5)
        .attr('y', 15)
        .attr('fill', 'red')
        .text(`${(analysisResults.cumulativeVariance[1] * 100).toFixed(1)}% variance`);
        
    // Store references for updating
    svg.dimensionLine = dimensionLine;
    svg.varianceText = varianceText;
}

// Function to update scree plot based on selected dimensionality
function updateScreePlot(dimension) {
    const svg = d3.select('#scree-plot svg');
    const xScale = svg.select('.x-axis').node().__scale;
    
    svg.dimensionLine
        .attr('x1', xScale(dimension - 1))
        .attr('x2', xScale(dimension - 1));
        
    svg.varianceText
        .attr('x', xScale(dimension - 1) + 5)
        .text(`${(analysisResults.cumulativeVariance[dimension - 1] * 100).toFixed(1)}% variance`);
}

// Function to create biplot
function createBiplot() {
    const width = 500;
    const height = 400;
    const margin = { top: 30, right: 30, bottom: 50, left: 50 };
    
    // Create SVG
    const svg = d3.select('#biplot')
        .append('svg')
        .attr('width', width)
        .attr('height', height);
        
    const g = svg.append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`);
        
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Get first two principal components
    const pc1 = analysisResults.pcScores.map(d => d[0]);
    const pc2 = analysisResults.pcScores.map(d => d[1]);
    
    // Create scales
    const xScale = d3.scaleLinear()
        .domain([d3.min(pc1) * 1.1, d3.max(pc1) * 1.1])
        .range([0, innerWidth])
        .nice();
        
    const yScale = d3.scaleLinear()
        .domain([d3.min(pc2) * 1.1, d3.max(pc2) * 1.1])
        .range([innerHeight, 0])
        .nice();
        
    // Create axes
    const xAxis = d3.axisBottom(xScale);
    const yAxis = d3.axisLeft(yScale);
    
    g.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0,${innerHeight})`)
        .call(xAxis);
        
    g.append('g')
        .attr('class', 'y-axis')
        .call(yAxis);
        
    // Add axis labels
    g.append('text')
        .attr('text-anchor', 'middle')
        .attr('x', innerWidth / 2)
        .attr('y', innerHeight + 40)
        .text(`Principal Component 1 (${(analysisResults.explainedVariance[0] * 100).toFixed(1)}% variance)`);
        
    g.append('text')
        .attr('text-anchor', 'middle')
        .attr('transform', `translate(${-35},${innerHeight / 2}) rotate(-90)`)
        .text(`Principal Component 2 (${(analysisResults.explainedVariance[1] * 100).toFixed(1)}% variance)`);
        
    // Create scatter plot
    g.selectAll('.dot')
        .data(analysisResults.pcScores)
        .enter()
        .append('circle')
        .attr('class', 'dot')
        .attr('cx', d => xScale(d[0]))
        .attr('cy', d => yScale(d[1]))
        .attr('r', 5)
        .attr('fill', '#4682b4')
        .attr('opacity', 0.7);
        
    // Origin lines
    g.append('line')
        .attr('x1', xScale(0))
        .attr('x2', xScale(0))
        .attr('y1', 0)
        .attr('y2', innerHeight)
        .attr('stroke', '#ccc')
        .attr('stroke-width', 1);
        
    g.append('line')
        .attr('x1', 0)
        .attr('x2', innerWidth)
        .attr('y1', yScale(0))
        .attr('y2', yScale(0))
        .attr('stroke', '#ccc')
        .attr('stroke-width', 1);
}

// Function to create attributes table
function createAttributesTable() {
    const tableContainer = d3.select('#attributes-table');
    
    const table = tableContainer.append('table');
    const thead = table.append('thead');
    const tbody = table.append('tbody');
    
    // Create header
    thead.append('tr')
        .selectAll('th')
        .data(['Rank', 'Attribute', 'PCA Loading Score'])
        .enter()
        .append('th')
        .text(d => d);
        
    // Create rows (top 10 attributes)
    const rows = tbody.selectAll('tr')
        .data(analysisResults.attributeRanking.slice(0, 10))
        .enter()
        .append('tr')
        .attr('class', (d, i) => i < 4 ? 'highlight' : '');
        
    // First column: rank
    rows.append('td')
        .text((d, i) => i + 1);
        
    // Second column: attribute name
    rows.append('td')
        .text(d => d.name);
        
    // Third column: loading score
    rows.append('td')
        .text(d => d.score.toFixed(4));
}

